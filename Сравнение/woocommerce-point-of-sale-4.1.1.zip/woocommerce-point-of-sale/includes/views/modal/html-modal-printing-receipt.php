<div class="md-modal md-dynamicmodal md-message" id="modal-printing-receipt">
    <div class="md-content">
        <div>
            <div class="md-message-icon">
        		<span class="dashicons printing-receipt-icon"></span>
        	</div>
		    <p><?php _e('The receipt is being generated for printing.', 'wc_point_of_sale'); ?></p>
        </div>
    </div>
</div>