=== WooCommerce Local Pickup Plus ===
Author: woothemes, skyverge
Tags: woocommerce
Requires at least: 4.1
Tested up to: 4.5.2
Requires WooCommerce at least: 2.4.13
Tested WooCommerce up to: 2.6.0

A shipping plugin for WooCommerce that allows the store operator to define local pickup locations, which the customer can then choose from when making a purchase.

See http://docs.woothemes.com/document/local-pickup-plus/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-shipping-local-pickup-plus' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
