<div class="md-modal md-dynamicmodal" id="modal-redirect-payment">
    <div class="md-content">
        <div>
            <div class="sa-icon sa-success" style="display: block;">
		      <span class="dashicons dashicons-admin-links"></span>
		    </div>
	        <div id="payment_result_message"></div>
        </div>
    </div>
</div>