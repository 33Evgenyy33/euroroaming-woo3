### AffiliateWP Supplemental docs

This file provides a non-empty directory for inclusion into the repository,
as well as brief information on how to add a supplemental doc to the AffiliateWP
developer documentation.

----

Supplemental docs can be added by creating a new `.md` doc in this directory. The doc must have a filename matching the hook, function, method or class for which you'd like to provide documentation.
