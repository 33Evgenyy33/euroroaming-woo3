<div class="md-modal md-dynamicmodal" id="modal-permission-denied">
    <div class="md-content">
		<h3>Error</h3>
		<div>
        	<center>
			<p class="currently-editing wp-tab-first" tabindex="0"><?php _e( 'You do not have permission to access this register.', 'wc_point_of_sale' ); ?></p>
	        <p>
	            <a class="button" href="<?php echo admin_url('admin.php?page=wc_pos_registers' ); ?>"><?php _e( 'All Registers', 'wc_point_of_sale' ); ?></a>
	        </p>
        	</center>
		</div>
	</div>
</div>