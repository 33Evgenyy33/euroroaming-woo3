<?php

class Affiliate_WP_Import {
	
	public function __construct() {}

}