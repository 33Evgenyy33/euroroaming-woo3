=== Payment Gateway Of FastSpring For WooCommerce ===
Contributors: deligence 
Tags: gateway, integration, payment, payment gateway, fast spring, fastspring, woocommerce, woocommerce fastspring
Donate link: 
Requires at least: 3.0.0
Tested up to: 4.5.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

You are able to integrate your FastSpring payment gateway plugin  with WooCommerce install. With FastSpring, you can pay by credit/debit cards in safe way.

== Description ==

You are able to integrate your FastSpring payment gateway plugin  with WooCommerce install. With FastSpring, you can pay by credit/debit cards in safe way.
FastSpring is most widely used payment gateway to process payments online and accepts Visa, MasterCard, JCB and other variants of cards.

== Installation ==


1> Install the plugin as a normal plugin. 

2> Click on plugins menu and you see all the installed plugins.

3> Now Activate your plugin.

4> Click on Settings link of your plugin and enter the required details.

5> Now Click on Save Changes button.

6> set 	HTTP Callback url(Notifications) in FastSpring for order update after making the payment and enter the url like

	scheme://host/wp-content/plugins/paymentgatewayoffastspringforwoocommerce/fastspring-callback.php?task=notify



== Frequently Asked Questions ==
* Initial release.

== Screenshots ==
1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png


== Changelog ==
= 1.0.0 - 25.01.2016 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 - 25.01.2016 =
* Initial release.

