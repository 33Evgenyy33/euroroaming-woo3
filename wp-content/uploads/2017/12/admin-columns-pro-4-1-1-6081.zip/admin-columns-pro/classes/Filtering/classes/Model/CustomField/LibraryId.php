<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ACP_Filtering_Model_CustomField_LibraryId extends ACP_Filtering_Model_CustomField_Image {

	// @see ACP_Filtering_Model_CustomField_Image

}
