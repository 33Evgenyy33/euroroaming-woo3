<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ACP_Export_Model_CustomField_Count extends ACP_Export_Model_Value {

	// @see ACP_Export_Model_Value

}
