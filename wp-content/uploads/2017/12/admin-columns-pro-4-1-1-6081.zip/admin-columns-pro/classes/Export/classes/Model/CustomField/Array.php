<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ACP_Export_Model_CustomField_Array extends ACP_Export_Model_Value {

	// @see ACP_Export_Model_Value

}
