<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ACP_Export_Model_CustomField_TitleById extends ACP_Export_Model_StrippedValue {

	// @see ACP_Export_Model_Value

}
