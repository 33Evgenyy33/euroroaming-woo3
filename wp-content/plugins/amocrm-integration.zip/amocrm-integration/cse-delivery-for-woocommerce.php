<?php

/**
 * Plugin Name: AmoCrm for Woocommerce
 * Plugin URI: https://euroroaming.ru
 * Description: AmoCrm for Woocommerce
 * Version: 1.0.0
 * Author: Evgeny Egorov
 * Author URI: https://euroroaming.ru
 * License: GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * Domain Path: /lang
 * Text Domain: euroroaming
 */

if (!defined('WPINC')) {
    die;
}
require_once __DIR__ . '/amocrm.phar';

/*
 * Check if WooCommerce is active
 */
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {

    function is_category_sim_karty($order_id)
    {
        //Получение заказа
        $order = new WC_Order($order_id);

        //Проверка заказа на категорию товара
        $items = $order->get_items();
        $product_id = 0;
        foreach ($items as $item) {
            $product_id = $item['product_id'];
            break;
        }
        $product_cats = get_the_terms($product_id, 'product_cat');
        $i_sim = 0;
        foreach ($product_cats as $product_cat) {
            if ($product_cat->slug == 'sim-karty')
                $i_sim++;
        }
        //если категория не 'сим-карты' выходим
        if ($i_sim === 0)
            return false;
        else return true;
    }

    function amocrm_contact()
    {

    }

    function amocrm_create_order($order_id)
    {

        //если категория не 'сим-карты' выходим
        if (!is_category_sim_karty($order_id)) return;


//        $myfile = fopen("processing-".$order_id.".txt", "w") or die("Unable to open file!");
//        file_put_contents("processing-".$order_id.".txt", $product_cat); //get_post_meta($order_id,'_billing_phone', true)
//        file_put_contents("processing-".$order_id.".txt", print_r($order_by,  true));
//        error_log( "Payment has been received for order". print_r($items) );

        try {
            $amo = new \AmoCRM\Client('new5909c3a25d8be', '33Evgenyy33@gmail.com', '9124c01e6179cd194b5986ba09a73258');

            $order = new WC_Order($order_id);//Получение объекта заказа
            $items = $order->get_items();//Получение товаров заказа
            $ordet_total = $order->get_total();//Стоимость заказ

            //получаем способ доставки
            $shipping_method = @array_shift($order->get_shipping_methods());
            $shipping_method_id = $shipping_method['method_id'];

            //проверяем оформлен заказ на сайте или в ТА (Если в ТА, то ответ POS)
            $order_by = get_post_meta($order_id, '_created_via', true);

            $lead = $amo->lead;//Создаем сделку
            //$lead->debug(true); // Режим отладки
            $lead['name'] = 'Заказ #' . $order_id;


            switch ($order->get_status()) {
                case 'processing':
                    $lead['status_id'] = 15447709;
                    break;
                case 'on-hold':
                    $lead['status_id'] = 15447712;
                    break;
                case 'point-of-sale':
                    $lead['status_id'] = 15447688;
                    break;
            }


            $lead['price'] = $ordet_total;
            //$lead['responsible_user_id'] = 1468330; //Ответственный менеджер
            //$lead['visitor_uid'] = '12345678-52d2-44c2-9e16-ba0052d9f6d6';

            if ($order_by == 'POS') {
                $lead->addCustomField(187241, 404987); //Статус доставки ТА
            }
            if ($shipping_method_id == 'local_pickup_plus') {
                $lead->addCustomField(187241, 404983); //Статус доставки Выдача
            }
            if ($shipping_method_id == 'flat_rate:1') {
                $lead->addCustomField(187241, 404985); //Статус доставки Почта РФ
            }
            if ($shipping_method_id != 'local_pickup_plus' && $shipping_method_id != 'flat_rate:1') {
                $lead->addCustomField(187241, 404981); //Статус доставки Курьерка
            }


            $operators_array = array(
                'orange' => 0,
                'vodafone' => 0,
                'ortel' => 0,
                'gs_classic' => 0,
                'gs_internet' => 0,
                'gs_usa' => 0,
                'europasim' => 0,
                'travelchat' => 0,
            );


            foreach ($items as $item) {
                switch ($item['product_id']) {
                    case 23065: //orange
                        $operators_array['orange'] += $item['qty'];
                        break;
                    case 23047: //vodafone
                        $operators_array['vodafone'] += $item['qty'];
                        break;
                    case 23090: //ortel
                        $operators_array['ortel'] += $item['qty'];
                        break;
                    case 23042: //GLOBALSIM «Classic»
                        $operators_array['gs_classic'] += $item['qty'];
                        break;
                    case 23085: //GLOBALSIM «Internet»
                        $operators_array['gs_internet'] += $item['qty'];
                        break;
                    case 23026: //GLOBALSIM с тарифом «США»
                        $operators_array['gs_usa'] += $item['qty'];
                        break;
                    case 23037: //EuropaSim
                        $operators_array['europasim'] += $item['qty'];
                        break;
                    case 23031: //TravelChat
                        $operators_array['travelchat'] += $item['qty'];
                        break;
                    case 23180: //Three
                        $operators_array['three'] += $item['qty'];
                        break;
                }
            }

            foreach ($operators_array as $key => $value) {

                if ($value == 0) continue;

                switch ($key) {
                    case 'orange': //orange
                        $lead->addCustomField(187211, $value);
                        break;
                    case 'vodafone': //vodafone
                        $lead->addCustomField(187225, $value);
                        break;
                    case 'ortel': //ortel
                        $lead->addCustomField(187227, $value);
                        break;
                    case 'gs_classic': //GLOBALSIM «Classic»
                        $lead->addCustomField(187229, $value);
                        break;
                    case 'gs_internet': //GLOBALSIM «Internet»
                        $lead->addCustomField(187231, $value);
                        break;
                    case 'gs_usa': //GLOBALSIM с тарифом «США»
                        $lead->addCustomField(187233, $value);
                        break;
                    case 'europasim': //EuropaSim
                        $lead->addCustomField(187237, $value);
                        break;
                    case 'travelchat': //TravelChat
                        $lead->addCustomField(187239, $value);
                        break;
                    case 'three': //Three
                        $lead->addCustomField(187235, $value);
                        break;
                }
            }


            $id_lead = $lead->apiAdd();

            $client_name = get_post_meta($order_id, '_billing_first_name', true);
            $client_last_name = get_post_meta($order_id, '_billing_last_name', true);
            $client_email = get_post_meta($order_id, '_billing_email', true);
            $client_phone = get_post_meta($order_id, '_billing_phone', true);

            $contact = $amo->contact;

            $contacts_list = $amo->contact->apiList([
                'query' => $client_phone,
            ]);

            //Если контакта нет в Амо - создаем без ответственного и привязываем заказ
            if (!$contacts_list) {
                $contact['name'] = $client_name . ' ' . $client_last_name;
                $contact->addCustomField(57524, [
                    [$client_email, 'PRIV'],
                ]);
                $contact->addCustomField(57522, [
                    [$client_phone, 'MOB'],
                ]);
                $contact['linked_leads_id'] = $id_lead;
                $id_contact = $contact->apiAdd();
            } else { //Контакт есть. Берем самый первый контакт и привязывает к сделке. У сделки обновляем ответственного.

                $contact_id = $contacts_list[0]['id'];
                $contact_responsible_user_id = $contacts_list[0]['responsible_user_id'];
                $linked_leads_id = $contacts_list[0]['linked_leads_id'];

                if (count($linked_leads_id) == 0) {
                    $contact['linked_leads_id'] = $id_lead;
                } else {
                    array_push($linked_leads_id, $id_lead);
                    $contact['linked_leads_id'] = $linked_leads_id;
                }

                $myfile = fopen("processing-" . $order_id . ".txt", "w") or die("Unable to open file!");
                file_put_contents("processing-" . $order_id . ".txt", print_r($contact['linked_leads_id'], true)); //get_post_meta($order_id,'_billing_phone', true)

                $contact->apiUpdate((int)$contact_id, 'now');

                $lead = $amo->lead;
                $lead['responsible_user_id'] = $contact_responsible_user_id;
                $lead->apiUpdate((int)$id_lead, 'now');

            }


        } catch (\AmoCRM\Exception $e) {
            error_log('Error (%d): %s', $e->getCode(), $e->getMessage());
        }
    }

    function woocommerce_order_statuses($order_id)
    {
        try {
            $amo = new \AmoCRM\Client('new5909c3a25d8be', '33Evgenyy33@gmail.com', '9124c01e6179cd194b5986ba09a73258');

            //Проверяем существует ли заказ в Амо
            $lead_is_create = $amo->lead->apiList([
                'query' => 'Заказ #' . $order_id,
            ]);

            //Заказа нет в Амо
            if (!$lead_is_create) {
                amocrm_create_order($order_id);
                return;
            }

            $myfile = fopen("processing-" . $order_id . ".txt", "w") or die("Unable to open file!");
            file_put_contents("processing-" . $order_id . ".txt", print_r($lead_is_create, true)); //get_post_meta($order_id,'_billing_phone', true)


            //Заказ есть в Амо
            $order = new WC_Order($order_id);//Получение объекта заказа
            $lead = $amo->lead;//Создаем сделку

            switch ($order->get_status()) {
                case 'processing':
                    $lead['status_id'] = 15447709;
                    break;
                case 'order-issued':
                    $lead['status_id'] = 15447703;
                    break;
                case 'on-hold':
                    $lead['status_id'] = 15447712;
                    break;
                case 'waiting-delivery':
                    $lead['status_id'] = 14805337;
                    break;
                case 'point-of-sale':
                    $lead['status_id'] = 15447688;
                    break;
                case 'waiting-for-passp':
                    $lead['status_id'] = 15447700;
                    break;
                case 'activating-by-dat':
                    $lead['status_id'] = 14805340;
                    break;
                case 'pending-activatio':
                    $lead['status_id'] = 15447691;
                    break;
                case 'orange-completed':
                    $lead['status_id'] = 15447697;
                    break;
                case 'ortel-completed':
                    $lead['status_id'] = 14805331;
                    break;
                case 'vodafone-complete':
                    $lead['status_id'] = 15447694;
                    break;
                case 'instructions-comp':
                    $lead['status_id'] = 15447706;
                    break;
                case 'balance-refilled':
                    $lead['status_id'] = 14805334;
                    break;
                case 'completed':
                    $lead['status_id'] = 15447715;
                    break;
                case 'cancelled':
                    $lead['status_id'] = 15447718;
                    break;
                case 'refunded':
                    $lead['status_id'] = 15495493;
                    break;
            }

            $lead->apiUpdate((int)$lead_is_create[0]['id'], 'now');


        } catch (\AmoCRM\Exception $e) {
            error_log('Error (%d): %s', $e->getCode(), $e->getMessage());
        }

    }

    add_action('woocommerce_order_status_processing', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_order-issued', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_on-hold', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_waiting-delivery', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_point-of-sale', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_waiting-for-passp', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_activating-by-dat', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_pending-activatio', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_orange-completed', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_ortel-completed', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_vodafone-complete', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_instructions-comp', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_balance-refilled', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_completed', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_cancelled', 'woocommerce_order_statuses', 10, 1);
    add_action('woocommerce_order_status_refunded', 'woocommerce_order_statuses', 10, 1);

    add_action('woocommerce_payment_complete', 'woocommerce_order_statuses', 10, 1);
}