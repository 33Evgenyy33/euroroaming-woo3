<div class="md-modal md-dynamicmodal" id="modal-lock-screen">
    <div class="md-content">
        <div>
            <div class="sa-icon sa-success" style="display: block;">
		      <span class="dashicons dashicons-lock"></span>
		    </div>
		    <p><?php _e('Enter password to unlock', 'wc_point_of_sale'); ?></p>
		    <input type="password" id="unlock_password" autocomplete="off">
		    <burron class="button button-primary" id="unlock_button"><?php _e('Unlock', 'wc_point_of_sale'); ?></burron>
        </div>
    </div>
</div>