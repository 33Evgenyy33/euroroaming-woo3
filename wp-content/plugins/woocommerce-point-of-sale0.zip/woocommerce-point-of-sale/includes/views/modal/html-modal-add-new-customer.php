<!-- Add New Customer Popup box -->
<?php
