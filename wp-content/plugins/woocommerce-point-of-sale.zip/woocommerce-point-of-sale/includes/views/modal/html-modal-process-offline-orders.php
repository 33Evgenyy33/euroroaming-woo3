<div class="md-modal md-dynamicmodal md-message" id="modal-offline-orders">
    <div class="md-content">
        <div>
            <p><?php _e('Offline orders processing now. Please wait.', 'wc_point_of_sale'); ?></p>
            <div class="progressbar"></div>
        </div>
    </div>
</div>