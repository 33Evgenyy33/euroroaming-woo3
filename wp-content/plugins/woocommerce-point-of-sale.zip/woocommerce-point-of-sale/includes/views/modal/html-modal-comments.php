<div class="md-modal full-width md-dynamicmodal md-close-by-overlay" id="modal-order_comments">
    <div class="md-content">
        <h1><?php _e('Notes', 'wc_point_of_sale'); ?><span class="md-close close-order-comments"></span></h1>
        <div>
            <textarea name="order_comments" id="order_comments"></textarea>
        </div>
        <div class="wrap-button">
            <button class="button button-primary wp-button-large alignright" type="button" id="save_order_comments"><?php _e('Add Note', 'wc_point_of_sale'); ?></button>
        </div>
    </div>
</div>